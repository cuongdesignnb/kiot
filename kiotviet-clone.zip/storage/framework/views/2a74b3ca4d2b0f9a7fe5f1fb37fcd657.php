<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hóa đơn - <?php echo e($invoice->code); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Arial', 'Helvetica', sans-serif; font-size: 13px; line-height: 1.5; color: #333; }
        .receipt { max-width: 320px; margin: 0 auto; padding: 12px; }
        .header { text-align: center; padding-bottom: 10px; border-bottom: 1px dashed #999; margin-bottom: 10px; }
        .company-name { font-size: 16px; font-weight: bold; text-transform: uppercase; }
        .doc-title { font-size: 15px; font-weight: bold; text-align: center; margin: 10px 0 8px; text-transform: uppercase; }
        .info { margin-bottom: 10px; }
        .info-row { display: flex; margin-bottom: 2px; }
        .info-label { min-width: 90px; color: #666; }
        .info-value { flex: 1; font-weight: 500; }
        .items { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        .items th { text-align: left; padding: 4px 2px; border-bottom: 1px solid #333; font-size: 12px; font-weight: bold; }
        .items td { padding: 4px 2px; border-bottom: 1px dashed #ddd; font-size: 12px; }
        .items .r { text-align: right; }
        .items .product-name { font-weight: 500; }
        .items .product-sku { font-size: 10px; color: #888; }
        .sep { border: none; border-top: 1px dashed #999; margin: 8px 0; }
        .sum-row { display: flex; justify-content: space-between; padding: 2px 0; font-size: 13px; }
        .sum-total { font-weight: bold; font-size: 15px; border-top: 1px solid #333; padding-top: 5px; margin-top: 4px; }
        .sum-highlight { color: #d00; }
        .footer { text-align: center; margin-top: 12px; padding-top: 10px; border-top: 1px dashed #999; font-size: 11px; color: #666; }
        .btn-print { display: block; margin: 15px auto 0; padding: 8px 24px; background: #2563eb; color: #fff; border: none; border-radius: 4px; font-size: 13px; cursor: pointer; }
        .btn-print:hover { background: #1d4ed8; }
        @media print { body { margin: 0; } .receipt { max-width: none; } .no-print { display: none !important; } }
    </style>
</head>
<body>
    <div class="receipt">
        <div class="header">
            <div class="company-name"><?php echo e(config('app.name', 'KiotViet')); ?></div>
        </div>

        <div class="doc-title">Hóa đơn bán hàng</div>

        <div class="info">
            <div class="info-row"><span class="info-label">Mã hóa đơn:</span><span class="info-value"><?php echo e($invoice->code); ?></span></div>
            <div class="info-row"><span class="info-label">Ngày tạo:</span><span class="info-value"><?php echo e($invoice->created_at->format('d/m/Y H:i')); ?></span></div>
            <div class="info-row"><span class="info-label">Thu ngân:</span><span class="info-value"><?php echo e($invoice->created_by_name ?? 'Admin'); ?></span></div>
            <?php if($invoice->customer): ?>
            <div class="info-row"><span class="info-label">Khách hàng:</span><span class="info-value"><?php echo e($invoice->customer->name); ?></span></div>
            <?php if($invoice->customer->phone): ?>
            <div class="info-row"><span class="info-label">SĐT:</span><span class="info-value"><?php echo e($invoice->customer->phone); ?></span></div>
            <?php endif; ?>
            <?php if($invoice->customer->address): ?>
            <div class="info-row"><span class="info-label">Địa chỉ:</span><span class="info-value"><?php echo e($invoice->customer->address); ?></span></div>
            <?php endif; ?>
            <?php endif; ?>
        </div>

        <table class="items">
            <thead>
                <tr>
                    <th style="width:40%">Hàng hóa</th>
                    <th class="r">SL</th>
                    <th class="r">Đơn giá</th>
                    <th class="r">T.Tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div class="product-name"><?php echo e($item->product->name ?? 'Sản phẩm'); ?></div>
                        <?php if($item->product && $item->product->sku): ?>
                        <div class="product-sku"><?php echo e($item->product->sku); ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="r"><?php echo e($item->quantity); ?></td>
                    <td class="r"><?php echo e(number_format($item->price, 0, ',', '.')); ?></td>
                    <td class="r"><?php echo e(number_format($item->subtotal ?? $item->price * $item->quantity, 0, ',', '.')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <hr class="sep">

        <div>
            <div class="sum-row">
                <span>Tổng tiền hàng (<?php echo e($invoice->items->sum('quantity')); ?> sản phẩm):</span>
                <span><?php echo e(number_format($invoice->subtotal ?? $invoice->items->sum(fn($i) => $i->subtotal ?? $i->price * $i->quantity), 0, ',', '.')); ?></span>
            </div>
            <div class="sum-row">
                <span>Chiết khấu hóa đơn:</span>
                <span><?php echo e(number_format($invoice->discount ?? 0, 0, ',', '.')); ?></span>
            </div>
            <?php if($invoice->other_fees > 0): ?>
            <div class="sum-row">
                <span>Thu khác:</span>
                <span><?php echo e(number_format($invoice->other_fees, 0, ',', '.')); ?></span>
            </div>
            <?php endif; ?>
            <?php if($invoice->is_delivery && $invoice->delivery_fee > 0): ?>
            <div class="sum-row">
                <span>Phí giao hàng:</span>
                <span><?php echo e(number_format($invoice->delivery_fee, 0, ',', '.')); ?></span>
            </div>
            <?php endif; ?>
            <div class="sum-row">
                <span>Công nợ cũ:</span>
                <span><?php echo e(number_format($previousDebt ?? 0, 0, ',', '.')); ?></span>
            </div>
            <div class="sum-row sum-total">
                <span>Tổng cộng:</span>
                <span><?php echo e(number_format($invoice->total, 0, ',', '.')); ?></span>
            </div>
            <div class="sum-row">
                <span>Khách hàng thanh toán:</span>
                <span><?php echo e(number_format($invoice->customer_paid ?? 0, 0, ',', '.')); ?></span>
            </div>
            <?php
                $change = ($invoice->customer_paid ?? 0) - $invoice->total;
                $newDebt = ($previousDebt ?? 0) + ($change < 0 ? abs($change) : 0);
            ?>
            <div class="sum-row">
                <span>Công nợ còn lại:</span>
                <span><?php echo e(number_format($newDebt, 0, ',', '.')); ?></span>
            </div>
            <?php if($change > 0): ?>
            <div class="sum-row">
                <span>Tiền thừa trả khách:</span>
                <span><?php echo e(number_format($change, 0, ',', '.')); ?></span>
            </div>
            <?php endif; ?>
            <?php if($invoice->payment_method): ?>
            <div class="sum-row" style="font-size:12px; color:#666;">
                <span>Phương thức:</span>
                <span><?php echo e($invoice->payment_method === 'cash' ? 'Tiền mặt' : ($invoice->payment_method === 'bank' ? 'Chuyển khoản' : $invoice->payment_method)); ?></span>
            </div>
            <?php endif; ?>
        </div>

        <div class="footer">
            <?php if($invoice->note): ?>
            <div style="margin-bottom: 8px; font-style: italic;"><?php echo e($invoice->note); ?></div>
            <?php endif; ?>
            <div>Cảm ơn quý khách và hẹn gặp lại!</div>
            <div style="margin-top: 4px;"><?php echo e($invoice->created_at->format('d/m/Y H:i:s')); ?></div>
        </div>

        <button class="btn-print no-print" onclick="window.print()">🖨️ In hóa đơn</button>
    </div>
    <script>window.onload = function() { window.print(); };</script>
</body>
</html>
<?php /**PATH D:\Kiot\kiotviet-clone\resources\views/prints/invoice.blade.php ENDPATH**/ ?>