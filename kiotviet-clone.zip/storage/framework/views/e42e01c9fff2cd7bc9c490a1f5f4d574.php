<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đơn hàng - <?php echo e($order->code); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Times New Roman', serif; font-size: 12px; line-height: 1.4; }
        .invoice { max-width: 300px; margin: 0 auto; padding: 10px; }
        .header { text-align: center; margin-bottom: 15px; border-bottom: 1px dashed #000; padding-bottom: 10px; }
        .company-name { font-size: 16px; font-weight: bold; margin-bottom: 5px; }
        .company-info { font-size: 10px; }
        .invoice-title { font-size: 14px; font-weight: bold; margin: 10px 0; text-align: center; }
        .order-info { margin-bottom: 15px; }
        .order-info div { margin-bottom: 3px; }
        .items-table { width: 100%; margin-bottom: 15px; border-collapse: collapse; }
        .items-table th, .items-table td { padding: 3px; text-align: left; }
        .items-table th { border-bottom: 1px solid #000; font-weight: bold; }
        .items-table .qty, .items-table .price, .items-table .total { text-align: right; }
        .summary { border-top: 1px dashed #000; padding-top: 10px; }
        .summary-row { display: flex; justify-content: space-between; margin-bottom: 3px; }
        .total-row { font-weight: bold; font-size: 14px; border-top: 1px solid #000; padding-top: 5px; margin-top: 5px; }
        .footer { text-align: center; margin-top: 15px; border-top: 1px dashed #000; padding-top: 10px; font-size: 10px; }
        .delivery { margin-top: 10px; padding-top: 10px; border-top: 1px dashed #000; }
        @media print { body { margin: 0; } .invoice { max-width: none; } .no-print { display: none; } }
    </style>
</head>
<body>
    <div class="invoice">
        <div class="header">
            <div class="company-name"><?php echo e(config('app.name', 'KiotViet Clone')); ?></div>
            <div class="company-info">
                Hotline: 1900 6750
            </div>
        </div>

        <div class="invoice-title">ĐƠN ĐẶT HÀNG</div>

        <div class="order-info">
            <div><strong>Mã ĐH:</strong> <?php echo e($order->code); ?></div>
            <div><strong>Ngày:</strong> <?php echo e($order->created_at->format('d/m/Y H:i')); ?></div>
            <div><strong>Người tạo:</strong> <?php echo e($order->created_by_name ?? 'Admin'); ?></div>
            <div><strong>Trạng thái:</strong> <?php echo e($order->status); ?></div>
            <?php if($order->customer): ?>
            <div><strong>Khách hàng:</strong> <?php echo e($order->customer->name); ?></div>
            <?php if($order->customer->phone): ?>
            <div><strong>SĐT:</strong> <?php echo e($order->customer->phone); ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </div>

        <table class="items-table">
            <thead>
                <tr>
                    <th>Sản phẩm</th>
                    <th class="qty">SL</th>
                    <th class="price">Giá</th>
                    <th class="total">T.Tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($item->product->name ?? 'Sản phẩm'); ?>

                        <?php if($item->product && $item->product->sku): ?>
                        <br><small><?php echo e($item->product->sku); ?></small>
                        <?php endif; ?>
                    </td>
                    <td class="qty"><?php echo e($item->qty); ?></td>
                    <td class="price"><?php echo e(number_format($item->price, 0, ',', '.')); ?></td>
                    <td class="total"><?php echo e(number_format($item->subtotal ?? $item->price * $item->qty, 0, ',', '.')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="summary">
            <div class="summary-row">
                <span>Tổng tiền hàng:</span>
                <span><?php echo e(number_format($order->total_price, 0, ',', '.')); ?>đ</span>
            </div>
            <?php if($order->discount > 0): ?>
            <div class="summary-row">
                <span>Giảm giá:</span>
                <span>-<?php echo e(number_format($order->discount, 0, ',', '.')); ?>đ</span>
            </div>
            <?php endif; ?>
            <?php if($order->other_fees > 0): ?>
            <div class="summary-row">
                <span>Thu khác:</span>
                <span><?php echo e(number_format($order->other_fees, 0, ',', '.')); ?>đ</span>
            </div>
            <?php endif; ?>
            <div class="summary-row total-row">
                <span>TỔNG CỘNG:</span>
                <span><?php echo e(number_format($order->total_payment, 0, ',', '.')); ?>đ</span>
            </div>
            <div class="summary-row">
                <span>Khách thanh toán:</span>
                <span><?php echo e(number_format($order->amount_paid, 0, ',', '.')); ?>đ</span>
            </div>
        </div>

        <?php if($order->is_delivery && $order->receiver_name): ?>
        <div class="delivery">
            <div><strong>Giao hàng cho:</strong></div>
            <div><?php echo e($order->receiver_name); ?> - <?php echo e($order->receiver_phone); ?></div>
            <div><?php echo e(implode(', ', array_filter([$order->receiver_address, $order->receiver_ward, $order->receiver_district, $order->receiver_city]))); ?></div>
            <?php if($order->cod_amount > 0): ?>
            <div><strong>COD:</strong> <?php echo e(number_format($order->cod_amount, 0, ',', '.')); ?>đ</div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="footer">
            <div>Cảm ơn quý khách!</div>
            <?php if($order->note): ?>
            <div style="margin-top: 10px;"><em><?php echo e($order->note); ?></em></div>
            <?php endif; ?>
        </div>
    </div>
    <script>window.onload = function() { window.print(); };</script>
</body>
</html>
<?php /**PATH D:\Kiot\kiotviet-clone\resources\views/prints/order.blade.php ENDPATH**/ ?>